# SimpleAnimation

This is a sample that shows how to use Playable Graphs to animate objects in a manner similar to the Animation Component. 

## This repository is archived. The last compatible version tested is Unity 2018.3, though we expect the code to still be compatible with Unity 2019.3.
